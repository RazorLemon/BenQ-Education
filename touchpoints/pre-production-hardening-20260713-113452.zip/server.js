import express from "express";
import cors from "cors";
import { env } from "./config/env.js";
import authRoutes from "./routes/auth.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import {
  requireAuth
} from "./middleware/auth.middleware.js";
import teacherRoutes from "./routes/teacher.routes.js";
import studentRoutes from "./routes/student.routes.js";
import setupRoutes from "./routes/setup.routes.js";
import {
  corsOptions
} from "./config/cors.js";
import {
  errorHandler,
  notFoundHandler
} from "./middleware/error.middleware.js";
const app = express();

app.get(
  "/api/profile",
  requireAuth,
  (req, res) => {

    res.json({
      user: req.user
    });

  }
);

app.use(
 cors(corsOptions)
);
app.use(express.json());
app.use("/api/auth", authRoutes);
app.use("/api/admin",adminRoutes);
app.use("/api/teacher",teacherRoutes);
app.use("/api/student",studentRoutes);
app.use("/api/setup",setupRoutes);

app.get("/", (req,res)=>{
   res.send("Smart Classroom API Running");
});

app.use(notFoundHandler);
app.use(errorHandler);

app.listen(env.PORT, ()=>{
   console.log(`Server running on ${env.PORT}`);
});
